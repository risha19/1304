<!DOCTYPE html>
<html lang="ru">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Изменение документа  </title> 
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
              integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Lato&family=Lobster&display=swap');

            body {
                background-image: url("https://cdn.pixabay.com/photo/2016/09/01/19/13/confetti-1637197_960_720.jpg");
            }
            h2 {
                text-align: center;
                background-color: white;
                margin: 15px;
                font-size: 38px;
                text-transform: uppercase;
                text-decoration: underline;
                font-family: 'Lobster', cursive;
            }
            .flex-container {
                display: flex;
                flex-direction: row;
                justify-content: space-around;
                padding: 10px;
            }
            .card {

                border: 1px solid silver;
                height: 200px;
                width: 300px;

            }
            p {
                margin: 10px;
                text-align: center;
            }

            input {
                background-color: green;
                padding: 5px;
                color: white;
                border-radius: 5px;
                margin: 15px; 
            }
            div>h2 {
                margin-left: 45%; 
                text-align: center;
                width: 20%;
            }



        </style>
    </head>
    <body>
        <div>   
            <h2>К а р т и н к и</h2>
        </div>

        <div class="flex-container">

        </div>
        <script>
            let catalog = [
                {image: "/EDUCATION/testDiplom/images/dino.jpg"},
                {image: "/EDUCATION/testDiplom/images2/mappets.jpg"}
            ];
            createRows(catalog);
            function createRows(array) {

                let div = document.querySelector(".flex-container");
                for (let elem of array) {
                    let row = document.createElement("p");
                    row.innerHTML = `
                  <div class="picture">
                    <p><img class="card" src="${elem.image}" alt=""></p>
                    <input type="button"  value="Собрать картинку"> 
                 </div>    
                `;
                    div.append(row);
                }
            }


        </script>


        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    </body>
</html>


